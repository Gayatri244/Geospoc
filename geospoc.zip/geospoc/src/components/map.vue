<template>
  <div>
    <div class="split left">

      <div class="info ">
        <span>Center: {{ center }}</span>
        <span>Zoom: {{ zoom }}</span>
        <span>Bounds: {{ bounds }}</span>
      </div>
      <div>
        <!-- <h3 @click="createIdwiseChart('income-chart',0)">560040</h3>
        <h3 @click="createIdwiseChart('income-chart',1)">560022</h3>
        <h3 @click="createIdwiseChart('income-chart',2)">560091</h3> -->
        <label>Select Pincode: </label>
        <select v-model="index" @change="createIdwiseChart('income-chart',index)">
          <option value="">--Select--</option>
          <option v-for="(p,index) in dataArray" v-bind:value="index"> {{
                p }}</option>
        </select>
      </div>

      <div>
        <canvas id=" income-chart"></canvas>
      </div>
    </div>

    <div class="split right">
      <div class="centered">
        <l-map style="height: 600px; width: 1200px" :zoom="zoom" :center="center" @update:zoom="zoomUpdated"
          @update:center="centerUpdated" @update:bounds="boundsUpdated">
          <l-tile-layer :url="url"></l-tile-layer>
          <l-marker :lat-lng="center"></l-marker>
        </l-map>
      </div>
    </div>
  </div>
</template>

<script>
  import Chart from 'chart.js';
  import incomeChartData from '../assets/chart-data.js';
  var json = require('../assets/expenditure.json');

  import {
    LMap,
    LTileLayer,
    LMarker
  } from 'vue2-leaflet'
  export default {
    components: {
      LMap,
      LTileLayer,
      LMarker
    },
    data() {
      return {
        url: 'http://{s}.tile.osm.org/{z}/{x}/{y}.png',
        zoom: 13,
        center: [18.5568, 73.7974],
        bounds: null,

        incomeChartData: incomeChartData,
        dataArray: [],
        index: ''
      }
    },
    mounted() {
      // this.createChart('income-chart', incomeChartData);
    },
    created() {
      console.log("incomeChartData--- ", incomeChartData);
      json.forEach(e => {
        this.dataArray.push(e.pincode)
      })

    },
    methods: {
      zoomUpdated(zoom) {
        this.zoom = zoom;
      },
      centerUpdated(center) {
        this.center = center;
      },
      boundsUpdated(bounds) {
        this.bounds = bounds;
      },


      // createChart(chartId, chartData) {
      //   const ctx = document.getElementById(chartId);

      //   const myChart = new Chart(ctx, {
      //     type: chartData.type,
      //     data: chartData.data[0],
      //     options: chartData.options,
      //   });
      // },
      createIdwiseChart(chartId, Id) {
        const ctx = document.getElementById(chartId);
        const myChart = new Chart(ctx, {
          type: incomeChartData.type,
          data: incomeChartData.data[Id],
          options: incomeChartData.options
        });
      },
    }
  }

</script>

<style scoped>
  .split {
    height: 100%;
    width: 50%;
    position: fixed;
    z-index: 1;
    top: 0;
    overflow-x: hidden;
    padding-top: 20px;
  }

  .left {
    left: 0;
    background-color: rgb(236, 223, 223);
  }

  .right {
    right: 0;
    background-color: red;
  }

  .centered {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
  }

  .centered img {
    width: 150px;
    border-radius: 50%;
  }

</style>
